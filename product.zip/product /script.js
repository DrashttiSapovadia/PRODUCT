function randomID()
{
    return Math.floor(Math.random() * 1000)
}

const url = "http://localhost:3000/products/"
function msg(id)
{
    $.get(url + id,function(data)
    {
        var change = data.name.split("(")[0]
            $("#name").val(change)
            $("#price").val(data.price)
            $("#description").val(data.description)
            $("#button").hide()
            $("#edit").show()       
    }
    )
    $("#edit").click(function()
    {
        $.ajax({method : "PUT",
                url : url + id,
                data : 
                {
                    name: $("#name").val() + " (Drashti)",
                    price: $("#price").val(),
                    description: $("#description").val(),
                }
                })
                
    })
}

$(document).ready(function()
{
    $("#filtertable").hide()
    $("#edit").hide()
    $.get("http://localhost:3000/products/",function(data)
    {
        var product_data = "";
        $.each(data,function(key,value)
        {
            product_data += "<tr >";
            product_data += "<td>"+value.name+"</td>";
            product_data += "<td>"+value.price+"</td>";
            product_data += "<td>"+value.description+"</td>";
            product_data += "<td>"+`<input type="submit" id='${value.id}' onclick="msg('${value.id}')"  value="edit">`+"</td>";
        });
        $("#mytable").append(product_data)
    })
   

    $("#button").click(function(e)
    {
        e.preventDefault();
        $.post({url : "http://localhost:3000/products/",
                data : 
                {
                    id: randomID(),
                    name: $("#name").val() + " (Drashti)",
                    price: $("#price").val(),
                    description: $("#description").val(),
                }, 
               })
        
    })

    $("#filter").click(function()
    {
        $.get("http://localhost:3000/products/",function(data)
        {
            $("#mytable").hide()
            $("#filtertable").show()
            var product_data = "";
            $.each(data,function(key,value)
            {
               
               if(value.name.toLowerCase().includes(('drashti').toLowerCase())){
                product_data += "<tr >";
                product_data += "<td>"+value.name+"</td>";
                product_data += "<td>"+value.price+"</td>";
                product_data += "<td>"+value.description+"</td>";
                product_data += "<td>"+`<input type="submit" id='${value.id}' onclick="msg('${value.id}')"  value="edit">`+"</td>";
               }
            });
            $("#filtertable").append(product_data)
        })
    })
})   



